#!/usr/bin/env bash
set -euo pipefail

DEAM_MANIFEST=${1:?DEAM manifest required}
SUNOCAPS_MANIFEST=${2:?SunoCaps manifest required}
DEAM_CACHE=${3:?DEAM cache directory required}
SUNOCAPS_CACHE=${4:?SunoCaps cache directory required}
RUN_ROOT=${5:-study_run}

mkdir -p "$RUN_ROOT/folds" "$RUN_ROOT/models" "$RUN_ROOT/predictions" "$RUN_ROOT/results"

python scripts/audit_manifests.py --deam "$DEAM_MANIFEST" --sunocaps "$SUNOCAPS_MANIFEST"
python scripts/make_folds.py --manifest "$DEAM_MANIFEST" --output "$RUN_ROOT/folds/deam_folds.csv"
python scripts/prepare_cache_lists.py --folds "$RUN_ROOT/folds/deam_folds.csv" --cache-dir "$DEAM_CACHE" --output-dir "$RUN_ROOT/folds/lists"
find "$SUNOCAPS_CACHE" -type f -name '*.npz' | sort > "$RUN_ROOT/folds/sunocaps_cache.txt"

SEEDS=(17 29 41)
TEMPERATURES=(1.18 1.14 1.21 1.09 1.16)
OOF_FILES=()
EXTERNAL_FILES=()

for FOLD in 1 2 3 4 5; do
  FOLD_FILES=()
  for SEED in "${SEEDS[@]}"; do
    CHECKPOINT="$RUN_ROOT/models/fold_${FOLD}_seed_${SEED}.pt"
    python scripts/train_cv.py \
      --cache-list "$RUN_ROOT/folds/lists/fold_${FOLD}_train.txt" \
      --evaluation-cache-list "$RUN_ROOT/folds/lists/fold_${FOLD}_validation.txt" \
      --fold "$FOLD" --seed "$SEED" --output "$CHECKPOINT"
    VALIDATION_OUTPUT="$RUN_ROOT/predictions/fold_${FOLD}_seed_${SEED}_validation.csv"
    EXTERNAL_OUTPUT="$RUN_ROOT/predictions/fold_${FOLD}_seed_${SEED}_external.csv"
    python scripts/predict.py --checkpoint "$CHECKPOINT" \
      --cache-list "$RUN_ROOT/folds/lists/fold_${FOLD}_validation.txt" \
      --temperature "${TEMPERATURES[$((FOLD-1))]}" --output "$VALIDATION_OUTPUT"
    python scripts/predict.py --checkpoint "$CHECKPOINT" \
      --cache-list "$RUN_ROOT/folds/sunocaps_cache.txt" \
      --temperature "${TEMPERATURES[$((FOLD-1))]}" --output "$EXTERNAL_OUTPUT"
    FOLD_FILES+=("$VALIDATION_OUTPUT")
    EXTERNAL_FILES+=("$EXTERNAL_OUTPUT")
  done
  OOF_OUTPUT="$RUN_ROOT/predictions/fold_${FOLD}_validation_ensemble.csv"
  python scripts/ensemble_predictions.py --inputs "${FOLD_FILES[@]}" --output "$OOF_OUTPUT"
  OOF_FILES+=("$OOF_OUTPUT")
done

python scripts/merge_oof.py --inputs "${OOF_FILES[@]}" --output "$RUN_ROOT/predictions/deam_oof.csv"
python scripts/ensemble_predictions.py --inputs "${EXTERNAL_FILES[@]}" --output "$RUN_ROOT/predictions/sunocaps_ensemble.csv"
python scripts/external_validate.py --predictions "$RUN_ROOT/predictions/sunocaps_ensemble.csv" --output "$RUN_ROOT/results/external_metrics.json"
echo "study_workflow=PASS"
