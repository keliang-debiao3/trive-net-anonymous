from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def require_columns(frame: pd.DataFrame, required: set[str], label: str) -> None:
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"{label} missing columns: {sorted(missing)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--deam", required=True)
    parser.add_argument("--sunocaps", required=True)
    args = parser.parse_args()
    deam = pd.read_csv(args.deam)
    sunocaps = pd.read_csv(args.sunocaps)
    require_columns(deam, {"path", "song_id", "mu_v", "sd_v", "mu_a", "sd_a"}, "DEAM")
    require_columns(sunocaps, {"path", "source_id", "emotion"}, "SunoCaps")
    if deam.song_id.duplicated().any():
        raise ValueError("DEAM song_id must identify one recording")
    if sunocaps.groupby("source_id").size().max() > 4:
        raise ValueError("SunoCaps source groups exceed four variants")
    missing_audio = [value for value in deam.path.tolist() + sunocaps.path.tolist() if not Path(value).exists()]
    if missing_audio:
        raise FileNotFoundError(f"Missing audio files: {len(missing_audio)}")
    print(f"deam_records={len(deam)}")
    print(f"sunocaps_tracks={len(sunocaps)}")
    print(f"sunocaps_groups={sunocaps.source_id.nunique()}")
    print("manifest_audit=PASS")


if __name__ == "__main__":
    main()

