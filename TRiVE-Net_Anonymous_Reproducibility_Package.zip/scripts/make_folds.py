from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


def quadrant(frame: pd.DataFrame) -> np.ndarray:
    high_v = frame.mu_v.to_numpy() >= 5.0
    high_a = frame.mu_a.to_numpy() >= 5.0
    return np.select(
        [high_v & high_a, ~high_v & high_a, ~high_v & ~high_a, high_v & ~high_a],
        [0, 1, 2, 3],
    )


def safe_id(value: object) -> str:
    return "".join(character if character.isalnum() or character in "-_" else "_" for character in str(value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    frame = pd.read_csv(args.manifest)
    required = {"song_id", "mu_v", "mu_a"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    if frame.song_id.duplicated().any():
        raise ValueError("fold construction requires one row per song_id")
    frame = frame.copy()
    frame["record_id"] = [f"{row.song_id}_{index}" for index, row in frame.iterrows()]
    frame["cache_name"] = [safe_id(value) + ".npz" for value in frame.record_id]
    frame["quadrant"] = quadrant(frame)
    frame["outer_fold"] = -1
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=args.seed)
    for fold, (_, validation) in enumerate(splitter.split(frame, frame.quadrant, groups=frame.song_id), start=1):
        frame.loc[validation, "outer_fold"] = fold
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    counts = frame.groupby(["outer_fold", "quadrant"]).size().unstack(fill_value=0)
    print(counts.to_string())
    print("fold_assignment=PASS")


if __name__ == "__main__":
    main()
