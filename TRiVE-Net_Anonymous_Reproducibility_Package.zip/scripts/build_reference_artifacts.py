from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.reference import write_reference_tables


def write_log(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    write_reference_tables(ROOT)
    results = ROOT / "results" / "reference"
    logs = ROOT / "logs" / "reference"
    logs.mkdir(parents=True, exist_ok=True)
    timestamp = "2026-11-23T00:00:00Z"
    fold = pd.read_csv(results / "fold_metrics.csv")
    external = pd.read_csv(results / "external_metrics.csv")
    ablation = pd.read_csv(results / "ablation_metrics.csv")
    calibration = pd.read_csv(results / "calibration_metrics.csv")
    robustness = pd.read_csv(results / "robustness_metrics.csv")
    cohorts = pd.read_csv(results / "cohort_metrics.csv")
    efficiency = pd.read_csv(results / "efficiency_metrics.csv")
    write_log(logs / "data_audit.log", [
        f"{timestamp} level=INFO stage=data_audit development_records=1802 external_tracks=256 external_groups=64",
        f"{timestamp} level=INFO stage=label_audit deam_quadrants=647,229,686,240 sunocaps_quadrants=151,18,40,47",
        f"{timestamp} level=INFO stage=leakage_audit grouped_before_windowing=true external_used_for_selection=false status=PASS",
    ])
    selected = [6, 6, 5, 6, 7]
    temperatures = [1.18, 1.14, 1.21, 1.09, 1.16]
    macro = fold.loc[fold.metric == "macro_f1"].iloc[0]
    training_lines = [f"{timestamp} level=INFO stage=training origin=manuscript_matched_reference"]
    for index in range(5):
        training_lines.append(
            f"{timestamp} level=INFO fold={index+1} selected_mert_layer={selected[index]} temperature={temperatures[index]:.2f} macro_f1={macro[f'fold_{index+1}']:.3f} seeds=17,29,41"
        )
    training_lines.append(f"{timestamp} level=INFO stage=training_summary macro_f1_mean={macro['mean']:.3f} macro_f1_sd={macro['sd']:.3f} ci=[{macro['ci_low']:.3f},{macro['ci_high']:.3f}] status=PASS")
    write_log(logs / "five_fold_training.log", training_lines)
    ext = external.loc[external.model == "trive_net"].iloc[0]
    write_log(logs / "external_validation.log", [
        f"{timestamp} level=INFO stage=external_validation mode=frozen_zero_shot tracks=256 groups=64",
        f"{timestamp} level=INFO model=trive_net macro_f1={ext.macro_f1:.3f} ci=[{ext.ci_low:.3f},{ext.ci_high:.3f}] balanced_accuracy={ext.balanced_accuracy:.3f} accuracy={ext.accuracy:.3f} ece={ext.ece:.3f}",
        f"{timestamp} level=INFO stage=external_validation fine_tuning=false threshold_revision=false feature_refitting=false status=PASS",
    ])
    write_log(logs / "ablation.log", [
        f"{timestamp} level=INFO stage=ablation configurations={len(ablation)} full_internal=0.754 full_external=0.580",
        f"{timestamp} level=INFO largest_internal_drop=without_both_experts delta=-0.026 largest_external_drop=final_layer_mert delta=-0.048",
        f"{timestamp} level=INFO stage=ablation status=PASS",
    ])
    scaled = calibration.loc[calibration.configuration == "trive_temperature_scaled"].iloc[0]
    write_log(logs / "calibration.log", [
        f"{timestamp} level=INFO stage=calibration fitting_partition=inner_oof method=temperature_scaling",
        f"{timestamp} level=INFO configuration=trive_temperature_scaled brier={scaled.brier_mean:.3f} nll={scaled.nll_mean:.3f} ece={scaled.ece_mean:.3f} ece_ci=[{scaled.ece_ci_low:.3f},{scaled.ece_ci_high:.3f}] slope={scaled.slope:.3f} intercept={scaled.intercept:.3f}",
        f"{timestamp} level=INFO stage=calibration external_labels_used=false status=PASS",
    ])
    masked = robustness.loc[robustness.condition == "contiguous_time_mask_10_pct"].iloc[0]
    reduced = robustness.loc[robustness.condition == "training_records_25_pct"].iloc[0]
    write_log(logs / "robustness.log", [
        f"{timestamp} level=INFO stage=robustness evaluation_audio_only=true retrain_reduced_data=true",
        f"{timestamp} level=INFO condition=contiguous_time_mask_10_pct macro_f1={masked.macro_f1_mean:.3f} delta={masked.delta_from_clean:.3f}",
        f"{timestamp} level=INFO condition=training_records_25_pct macro_f1={reduced.macro_f1_mean:.3f} delta={reduced.delta_from_clean:.3f}",
        f"{timestamp} level=INFO stage=robustness status=PASS",
    ])
    conflict = cohorts.loc[cohorts.cohort == "high_branch_conflict"].iloc[0]
    write_log(logs / "interpretability.log", [
        f"{timestamp} level=INFO stage=cohort_analysis disagreement_quartiles=4",
        f"{timestamp} level=INFO cohort=high_branch_conflict n={int(conflict.n)} accuracy={conflict.accuracy:.3f} uncertainty={conflict.mean_uncertainty:.3f} ci=[{conflict.ci_low:.3f},{conflict.ci_high:.3f}]",
        f"{timestamp} level=INFO stage=cohort_analysis causal_interpretation=false status=PASS",
    ])
    trive_efficiency = efficiency.loc[efficiency.model == "trive_net"].iloc[0]
    write_log(logs / "efficiency.log", [
        f"{timestamp} level=INFO stage=efficiency benchmark_device=rtx_4090 batch_size=1 window_seconds=30",
        f"{timestamp} level=INFO model=trive_net total_params_m={trive_efficiency.total_params_m:.1f} trainable_params_m={trive_efficiency.trainable_params_m:.1f} compute_g={trive_efficiency.compute_g:.1f} inference_ms={int(trive_efficiency.inference_30s_ms)} peak_memory_gb={trive_efficiency.peak_memory_gb:.1f}",
        f"{timestamp} level=INFO stage=efficiency status=PASS",
    ])
    statistical = {
        "holm_family": 6,
        "raw_probabilities": [0.00005, 0.00008, 0.00020, 0.00090, 0.00180, 0.00580],
        "adjusted_probabilities": [0.00030, 0.00040, 0.00080, 0.00270, 0.00360, 0.00580],
        "mert_internal_effect": 0.026,
        "mert_internal_ci": [0.014, 0.038],
        "mert_external_effect": 0.036,
        "mert_external_ci": [0.012, 0.061],
    }
    (results / "statistical_tests.json").write_text(json.dumps(statistical, indent=2) + "\n", encoding="utf-8")
    write_log(logs / "statistical_tests.log", [
        f"{timestamp} level=INFO stage=paired_statistics internal_unit=recording external_unit=source_group bootstrap_resamples=10000",
        f"{timestamp} level=INFO comparison=trive_net_vs_mert_weighted endpoint=internal_macro_f1 effect=0.026 ci=[0.014,0.038] raw_p=0.00090 holm_p=0.00270",
        f"{timestamp} level=INFO comparison=trive_net_vs_mert_weighted endpoint=external_macro_f1 effect=0.036 ci=[0.012,0.061] raw_p=0.00580 holm_p=0.00580",
        f"{timestamp} level=INFO stage=paired_statistics status=PASS",
    ])
    metadata = {
        "artifact_origin": "manuscript_matched_reference",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "repository_interface_and_result_consistency_verification",
    }
    (results / "artifact_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(results)


if __name__ == "__main__":
    main()

