from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.calibration import apply_temperature
from trive_net.statistics import holm_adjust
from trive_net.targets import map_sunocaps_emotion, soft_quadrant_target


def main() -> None:
    target = soft_quadrant_target(6.5, 1.0, 4.0, 0.8)
    assert target.shape == (4,) and np.isclose(target.sum(), 1.0)
    assert map_sunocaps_emotion(" Happy ") == "HVHA"
    probability = np.asarray([[0.7, 0.1, 0.1, 0.1], [0.1, 0.6, 0.2, 0.1]])
    assert np.allclose(apply_temperature(probability, 1.2).sum(axis=1), 1.0)
    raw = [0.00005, 0.00008, 0.00020, 0.00090, 0.00180, 0.00580]
    expected = [0.00030, 0.00040, 0.00080, 0.00270, 0.00360, 0.00580]
    assert np.allclose(holm_adjust(raw), expected)
    print("light_checks=PASS")


if __name__ == "__main__":
    main()
