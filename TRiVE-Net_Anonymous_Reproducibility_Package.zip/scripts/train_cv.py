from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.losses import total_loss
from trive_net.metrics import classification_metrics
from trive_net.model import TRiVENet


class CachedDataset(Dataset):
    def __init__(self, paths: list[Path], layer: int):
        self.paths = paths
        self.layer = layer

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index: int):
        record = np.load(self.paths[index])
        return {
            "foundation": torch.from_numpy(record["mert_layers"][self.layer - 1]).float(),
            "tonal": torch.from_numpy(record["tonal_tokens"]).float(),
            "rhythmic": torch.from_numpy(record["rhythmic_tokens"]).float(),
            "soft_target": torch.from_numpy(record["soft_target"]).float(),
            "target_mean": torch.from_numpy(record["target_mean"]).float(),
            "observed_sd": torch.from_numpy(record["observed_sd"]).float(),
            "foundation_shifted": torch.from_numpy(record["mert_layers_shifted"][self.layer - 1]).float(),
            "tonal_shifted": torch.from_numpy(record["tonal_tokens_shifted"]).float(),
            "rhythmic_shifted": torch.from_numpy(record["rhythmic_tokens_shifted"]).float(),
        }


def collate(records: list[dict]) -> dict:
    minimum = min(item["foundation"].shape[0] for item in records)
    output = {}
    for name in ("foundation", "tonal", "rhythmic", "foundation_shifted", "tonal_shifted", "rhythmic_shifted"):
        modality_minimum = min(item[name].shape[0] for item in records)
        output[name] = torch.stack([item[name][:modality_minimum] for item in records])
    for name in ("soft_target", "target_mean", "observed_sd"):
        output[name] = torch.stack([item[name] for item in records])
    return output


def evaluate(model: TRiVENet, loader: DataLoader, device: torch.device) -> dict[str, float]:
    targets = []
    probabilities = []
    model.eval()
    with torch.inference_mode():
        for batch in loader:
            output = model(
                batch["foundation"].to(device),
                batch["tonal"].to(device),
                batch["rhythmic"].to(device),
            )
            targets.append(batch["soft_target"].argmax(dim=1).numpy())
            probabilities.append(output["probability"].cpu().numpy())
    return classification_metrics(np.concatenate(targets), np.concatenate(probabilities))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-list", required=True)
    parser.add_argument("--selection-cache-list", help="Inner-fold cache used only for early stopping")
    parser.add_argument("--evaluation-cache-list", help="Outer-fold cache evaluated only after fitting")
    parser.add_argument("--fold", type=int, required=True, choices=range(1, 6))
    parser.add_argument("--config", default=str(ROOT / "configs" / "trive_deam.yaml"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument(
        "--ablation",
        default="full",
        choices=["full", "without_fals", "without_tonal", "without_rhythmic", "without_both_experts", "without_soft_targets", "without_conflict_gate", "without_epsc", "without_va_loss", "final_layer_mert"],
    )
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text())
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    layer = config["study"]["selected_mert_layers"][args.fold - 1]
    if args.ablation in {"without_fals", "final_layer_mert"}:
        layer = 12
    paths = [Path(line.strip()) for line in Path(args.cache_list).read_text().splitlines() if line.strip()]
    dataset = CachedDataset(paths, layer)
    generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(dataset, batch_size=config["optimization"]["batch_size"], shuffle=True, collate_fn=collate, generator=generator)
    selection_loader = None
    if args.selection_cache_list:
        selection_paths = [Path(line.strip()) for line in Path(args.selection_cache_list).read_text().splitlines() if line.strip()]
        selection_loader = DataLoader(CachedDataset(selection_paths, layer), batch_size=config["optimization"]["batch_size"], shuffle=False, collate_fn=collate)
    evaluation_loader = None
    if args.evaluation_cache_list:
        evaluation_paths = [Path(line.strip()) for line in Path(args.evaluation_cache_list).read_text().splitlines() if line.strip()]
        evaluation_loader = DataLoader(CachedDataset(evaluation_paths, layer), batch_size=config["optimization"]["batch_size"], shuffle=False, collate_fn=collate)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TRiVENet(
        gamma=config["fusion"]["conflict_gamma"],
        use_tonal=args.ablation not in {"without_tonal", "without_both_experts", "final_layer_mert"},
        use_rhythmic=args.ablation not in {"without_rhythmic", "without_both_experts", "final_layer_mert"},
        use_conflict_gate=args.ablation != "without_conflict_gate",
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["optimization"]["learning_rate"], weight_decay=config["loss"]["lambda_weight_decay"])
    maximum_epochs = config["optimization"]["maximum_epochs"]
    warmup_epochs = config["optimization"]["warmup_epochs"]
    minimum_ratio = config["optimization"]["minimum_learning_rate"] / config["optimization"]["learning_rate"]

    def schedule(epoch: int) -> float:
        if epoch < warmup_epochs:
            return (epoch + 1) / warmup_epochs
        progress = (epoch - warmup_epochs) / max(maximum_epochs - warmup_epochs - 1, 1)
        return minimum_ratio + 0.5 * (1.0 - minimum_ratio) * (1.0 + np.cos(np.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
    amp_enabled = bool(config["optimization"]["mixed_precision"] and device.type == "cuda")
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    accumulation = int(config["optimization"]["gradient_accumulation"])
    history = []
    best_score = -np.inf
    best_state = None
    patience = 0
    for epoch in range(maximum_epochs):
        model.train()
        epoch_loss = 0.0
        kl_weight = config["loss"]["lambda_kl_max"] * min(1.0, (epoch + 1) / config["loss"]["kl_warmup_epochs"])
        optimizer.zero_grad(set_to_none=True)
        for batch_index, batch in enumerate(loader):
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp_enabled):
                output = model(batch["foundation"].to(device), batch["tonal"].to(device), batch["rhythmic"].to(device))
                shifted = None
                if args.ablation != "without_epsc":
                    shifted = model(batch["foundation_shifted"].to(device), batch["tonal_shifted"].to(device), batch["rhythmic_shifted"].to(device))
                soft_target = batch["soft_target"].to(device)
                if args.ablation == "without_soft_targets":
                    soft_target = torch.nn.functional.one_hot(soft_target.argmax(dim=1), num_classes=4).to(soft_target.dtype)
                losses = total_loss(
                    output,
                    soft_target,
                    batch["target_mean"].to(device),
                    batch["observed_sd"].to(device),
                    kl_weight,
                    shifted=shifted,
                    lambda_va=0.0 if args.ablation == "without_va_loss" else config["loss"]["lambda_va"],
                    lambda_consistency=config["loss"]["lambda_consistency"],
                    rho=config["loss"]["consistency_uncertainty_weight"],
                )
            scaler.scale(losses["total"] / accumulation).backward()
            should_step = (batch_index + 1) % accumulation == 0 or (batch_index + 1) == len(loader)
            if should_step:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), config["optimization"]["gradient_clip"])
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            epoch_loss += float(losses["total"].detach().cpu())
        scheduler.step()
        record = {"epoch": epoch + 1, "loss": epoch_loss / max(len(loader), 1), "kl_weight": kl_weight, "learning_rate": optimizer.param_groups[0]["lr"]}
        if selection_loader is not None:
            selection = evaluate(model, selection_loader, device)
            record.update({f"selection_{key}": value for key, value in selection.items()})
            if selection["macro_f1"] > best_score:
                best_score = selection["macro_f1"]
                best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
                patience = 0
            else:
                patience += 1
        history.append(record)
        if selection_loader is not None and patience >= config["optimization"]["early_stopping_patience"]:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    if evaluation_loader is not None:
        evaluation = evaluate(model, evaluation_loader, device)
        history.append({"outer_evaluation": evaluation, "selection_use": False})
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"model": model.state_dict(), "fold": args.fold, "selected_layer": layer, "seed": args.seed, "ablation": args.ablation, "config": config}, output_path)
    output_path.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()

