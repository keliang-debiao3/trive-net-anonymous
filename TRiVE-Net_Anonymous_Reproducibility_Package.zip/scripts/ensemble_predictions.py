from __future__ import annotations

import argparse
from functools import reduce
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    frames = []
    probability_columns = ["p0", "p1", "p2", "p3"]
    for index, path in enumerate(args.inputs):
        frame = pd.read_csv(path)
        keep = ["record_id", "source_id", *probability_columns]
        for optional in ("emotion", "target"):
            if optional in frame.columns:
                keep.append(optional)
        frame = frame[keep].copy()
        frame = frame.rename(columns={column: f"{column}_{index}" for column in probability_columns})
        frames.append(frame)
    merged = reduce(lambda left, right: left.merge(right, on=[column for column in left.columns if column in right.columns and not column.startswith("p")], how="inner"), frames)
    for column in probability_columns:
        merged[column] = merged[[f"{column}_{index}" for index in range(len(frames))]].mean(axis=1)
    drop = [column for column in merged.columns if any(column == f"{base}_{index}" for base in probability_columns for index in range(len(frames)))]
    merged = merged.drop(columns=drop)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(output, index=False)
    print(f"ensemble_predictions={len(merged)}")


if __name__ == "__main__":
    main()
