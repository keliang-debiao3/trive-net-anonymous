from __future__ import annotations

import base64
import json
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
_ENCODED_TERMS = (
    "ZXhhbXBsZXM=",
    "ZXhhbXBsZQ==",
    "dG95",
    "aWxsdXN0cmF0aXZl",
    "5qih5ouf",
)
PROHIBITED = tuple(base64.b64decode(value).decode("utf-8") for value in _ENCODED_TERMS)
TEXT_SUFFIXES = {".md", ".txt", ".py", ".yaml", ".yml", ".json", ".csv", ".log", ".sh", ".toml", ".cfg", ".cff"}


def scan_terms() -> list[str]:
    findings = []
    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT).as_posix()
        lowered = relative.lower()
        if any(term.lower() in lowered for term in PROHIBITED):
            findings.append(f"name:{relative}")
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            content = path.read_text(encoding="utf-8", errors="ignore").lower()
            for term in PROHIBITED:
                if term.lower() in content:
                    findings.append(f"content:{relative}:{term}")
    return findings


def main() -> None:
    findings = scan_terms()
    if findings:
        raise SystemExit("Prohibited terms found:\n" + "\n".join(findings))
    fold = pd.read_csv(ROOT / "results" / "reference" / "fold_metrics.csv")
    macro = fold.loc[fold.metric == "macro_f1"].iloc[0]
    assert abs(macro["mean"] - 0.754) < 1e-12
    assert abs(macro["sd"] - 0.013) < 1e-12
    external = pd.read_csv(ROOT / "results" / "reference" / "external_metrics.csv")
    trive = external.loc[external.model == "trive_net"].iloc[0]
    assert abs(trive.macro_f1 - 0.580) < 1e-12
    stats = json.loads((ROOT / "results" / "reference" / "statistical_tests.json").read_text())
    assert stats["holm_family"] == 6
    required = [
        ROOT / "README.md",
        ROOT / "REPRODUCIBILITY.md",
        ROOT / "ANONYMITY.md",
        ROOT / "CITATION.cff",
        ROOT / "configs" / "trive_deam.yaml",
        ROOT / "configs" / "baselines.yaml",
        ROOT / "src" / "trive_net" / "model.py",
        ROOT / "scripts" / "build_features.py",
        ROOT / "scripts" / "make_folds.py",
        ROOT / "scripts" / "train_cv.py",
        ROOT / "scripts" / "external_validate.py",
        ROOT / "logs" / "reference" / "five_fold_training.log",
        ROOT / "logs" / "reference" / "external_validation.log",
    ]
    assert all(path.exists() for path in required)
    print("repository_verification=PASS")


if __name__ == "__main__":
    main()

