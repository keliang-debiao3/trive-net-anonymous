from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--folds", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    frame = pd.read_csv(args.folds)
    required = {"outer_fold", "cache_name"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    cache_dir = Path(args.cache_dir).resolve()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for fold in range(1, 6):
        for split, selection in (
            ("train", frame.outer_fold != fold),
            ("validation", frame.outer_fold == fold),
        ):
            paths = [cache_dir / name for name in frame.loc[selection, "cache_name"]]
            missing_paths = [path for path in paths if not path.exists()]
            if missing_paths:
                raise FileNotFoundError(f"fold {fold} {split} missing cache records: {len(missing_paths)}")
            (output_dir / f"fold_{fold}_{split}.txt").write_text(
                "\n".join(str(path) for path in paths) + "\n",
                encoding="utf-8",
            )
    print("cache_lists=PASS")


if __name__ == "__main__":
    main()
