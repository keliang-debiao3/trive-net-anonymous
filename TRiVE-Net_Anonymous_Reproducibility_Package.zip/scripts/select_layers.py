from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def normalize(series: pd.Series) -> pd.Series:
    spread = series.max() - series.min()
    if spread == 0:
        return pd.Series(0.0, index=series.index)
    return (series - series.min()) / spread


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-metrics", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--probe-weight", type=float, default=0.55)
    parser.add_argument("--equivariance-weight", type=float, default=0.30)
    parser.add_argument("--redundancy-weight", type=float, default=0.15)
    parser.add_argument("--tolerance", type=float, default=0.002)
    args = parser.parse_args()
    frame = pd.read_csv(args.candidate_metrics)
    required = {"fold", "layer", "probe_score", "pitch_equivariance", "redundancy"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    selected = []
    scored = []
    for fold, subset in frame.groupby("fold"):
        subset = subset.copy()
        subset["fals_score"] = (
            args.probe_weight * normalize(subset.probe_score)
            + args.equivariance_weight * normalize(subset.pitch_equivariance)
            - args.redundancy_weight * normalize(subset.redundancy)
        )
        best = subset.fals_score.max()
        eligible = subset.loc[subset.fals_score >= best - args.tolerance]
        choice = eligible.sort_values(["layer", "fals_score"], ascending=[True, False]).iloc[0]
        selected.append({"fold": int(fold), "selected_layer": int(choice.layer), "fals_score": float(choice.fals_score)})
        scored.append(subset)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(selected).sort_values("fold").to_csv(output, index=False)
    pd.concat(scored).sort_values(["fold", "layer"]).to_csv(output.with_name(output.stem + "_all_layers.csv"), index=False)
    print(pd.DataFrame(selected).sort_values("fold").to_string(index=False))


if __name__ == "__main__":
    main()
