from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.statistics import holm_adjust, paired_macro_f1_bootstrap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--resamples", type=int, default=10000)
    args = parser.parse_args()
    data = np.load(args.predictions)
    names = [str(value) for value in data["model_names"]]
    target = data["target"]
    groups = data["groups"]
    proposed = data["prediction_trive_net"]
    results = []
    for name in names:
        baseline = data[f"prediction_{name}"]
        row = paired_macro_f1_bootstrap(target, proposed, baseline, groups, args.resamples)
        row["comparison"] = f"trive_net_vs_{name}"
        results.append(row)
    adjusted = holm_adjust([row["p_raw"] for row in results])
    for row, value in zip(results, adjusted):
        row["p_holm"] = value
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()

