from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import yaml
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.features import MERTExtractor, load_audio, mild_delivery_shift, rhythmic_tokens, split_windows, tonal_tokens
from trive_net.targets import soft_quadrant_target


def safe_id(value: object) -> str:
    return "".join(character if character.isalnum() or character in "-_" else "_" for character in str(value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--config", default=str(ROOT / "configs" / "trive_deam.yaml"))
    parser.add_argument("--dataset", choices=["deam", "sunocaps"], required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    config = yaml.safe_load(Path(args.config).read_text())
    frame = pd.read_csv(args.manifest)
    identifier = "song_id" if args.dataset == "deam" else "source_id"
    extractor = MERTExtractor(config["foundation"]["model_id"], args.device)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for row_index, row in tqdm(frame.iterrows(), total=len(frame)):
        record_id = f"{row[identifier]}_{row_index}"
        waveform = load_audio(row.path, config["audio"]["sample_rate"])
        shifted = mild_delivery_shift(waveform, record_id)
        windows, validity = split_windows(waveform, config["audio"]["sample_rate"], config["audio"]["window_seconds"])
        shifted_windows, _ = split_windows(shifted, config["audio"]["sample_rate"], config["audio"]["window_seconds"])
        clean_mert = [extractor(window, config["audio"]["sample_rate"]) for window in windows]
        shifted_mert = [extractor(window, config["audio"]["sample_rate"]) for window in shifted_windows]
        payload = {
            "record_id": np.asarray(record_id),
            "group_id": np.asarray(str(row[identifier])),
            "window_validity": validity,
            "mert_layers": np.concatenate(clean_mert, axis=1),
            "tonal_tokens": np.concatenate([tonal_tokens(window, config["audio"]["sample_rate"]) for window in windows], axis=0),
            "rhythmic_tokens": np.concatenate([rhythmic_tokens(window, config["audio"]["sample_rate"]) for window in windows], axis=0),
            "mert_layers_shifted": np.concatenate(shifted_mert, axis=1),
            "tonal_tokens_shifted": np.concatenate([tonal_tokens(window, config["audio"]["sample_rate"]) for window in shifted_windows], axis=0),
            "rhythmic_tokens_shifted": np.concatenate([rhythmic_tokens(window, config["audio"]["sample_rate"]) for window in shifted_windows], axis=0),
        }
        if args.dataset == "deam":
            payload.update({
                "soft_target": soft_quadrant_target(row.mu_v, row.sd_v, row.mu_a, row.sd_a),
                "target_mean": np.asarray([row.mu_v, row.mu_a], dtype=np.float32),
                "observed_sd": np.asarray([row.sd_v, row.sd_a], dtype=np.float32),
            })
        else:
            payload["emotion"] = np.asarray(str(row.emotion))
        np.savez_compressed(output_dir / f"{safe_id(record_id)}.npz", **payload)
    print(f"cached_records={len(frame)}")


if __name__ == "__main__":
    main()
