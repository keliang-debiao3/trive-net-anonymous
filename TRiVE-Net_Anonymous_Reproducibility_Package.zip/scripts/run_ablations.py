from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


CONFIGURATIONS = [
    "full",
    "without_fals",
    "without_tonal",
    "without_rhythmic",
    "without_both_experts",
    "without_soft_targets",
    "without_conflict_gate",
    "without_epsc",
    "without_va_loss",
    "final_layer_mert",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lists-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--fold", type=int, required=True, choices=range(1, 6))
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for configuration in CONFIGURATIONS:
        command = [
            sys.executable,
            str(root / "scripts" / "train_cv.py"),
            "--cache-list",
            str(Path(args.lists_dir) / f"fold_{args.fold}_train.txt"),
            "--evaluation-cache-list",
            str(Path(args.lists_dir) / f"fold_{args.fold}_validation.txt"),
            "--fold",
            str(args.fold),
            "--seed",
            str(args.seed),
            "--ablation",
            configuration,
            "--output",
            str(output / f"{configuration}_fold_{args.fold}_seed_{args.seed}.pt"),
        ]
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
