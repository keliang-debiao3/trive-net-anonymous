from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.calibration import apply_temperature
from trive_net.model import TRiVENet


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--cache-list", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--temperature", type=float, default=1.0)
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    ablation = checkpoint.get("ablation", "full")
    model = TRiVENet(
        gamma=checkpoint["config"]["fusion"]["conflict_gamma"],
        use_tonal=ablation not in {"without_tonal", "without_both_experts", "final_layer_mert"},
        use_rhythmic=ablation not in {"without_rhythmic", "without_both_experts", "final_layer_mert"},
        use_conflict_gate=ablation != "without_conflict_gate",
    )
    model.load_state_dict(checkpoint["model"])
    model.to(device).eval()
    layer = int(checkpoint["selected_layer"])
    paths = [Path(line.strip()) for line in Path(args.cache_list).read_text().splitlines() if line.strip()]
    rows = []
    with torch.inference_mode():
        for path in paths:
            record = np.load(path)
            output = model(
                torch.from_numpy(record["mert_layers"][layer - 1]).float().unsqueeze(0).to(device),
                torch.from_numpy(record["tonal_tokens"]).float().unsqueeze(0).to(device),
                torch.from_numpy(record["rhythmic_tokens"]).float().unsqueeze(0).to(device),
            )
            probability = apply_temperature(output["probability"].cpu().numpy(), args.temperature)[0]
            row = {
                "record_id": str(record["record_id"]),
                "source_id": str(record["group_id"]),
                **{f"p{index}": float(value) for index, value in enumerate(probability)},
                "uncertainty": float(output["uncertainty"].cpu().item()),
                "mean_valence": float(output["mean_va"][0, 0].cpu()),
                "mean_arousal": float(output["mean_va"][0, 1].cpu()),
            }
            if "emotion" in record:
                row["emotion"] = str(record["emotion"])
            if "soft_target" in record:
                row["target"] = int(np.asarray(record["soft_target"]).argmax())
            rows.append(row)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_path, index=False)
    print(f"predictions={len(rows)}")


if __name__ == "__main__":
    main()
