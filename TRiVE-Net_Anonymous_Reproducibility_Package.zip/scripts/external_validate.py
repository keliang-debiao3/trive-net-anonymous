from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from trive_net.metrics import classification_metrics
from trive_net.statistics import paired_macro_f1_bootstrap
from trive_net.targets import map_sunocaps_emotion


CLASS_INDEX = {"HVHA": 0, "LVHA": 1, "LVLA": 2, "HVLA": 3}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, help="CSV containing source_id, emotion, and p0 through p3")
    parser.add_argument("--comparison", help="Optional CSV with source_id and p0 through p3")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    frame = pd.read_csv(args.predictions)
    required = {"source_id", "emotion", "p0", "p1", "p2", "p3"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    y_true = np.asarray([CLASS_INDEX[map_sunocaps_emotion(value)] for value in frame.emotion], dtype=int)
    probability = frame[["p0", "p1", "p2", "p3"]].to_numpy(dtype=float)
    metrics = classification_metrics(y_true, probability)
    result: dict[str, object] = {"metrics": metrics, "tracks": len(frame), "source_groups": int(frame.source_id.nunique())}
    if args.comparison:
        other = pd.read_csv(args.comparison)
        merged = frame[["source_id"]].join(other[["source_id", "p0", "p1", "p2", "p3"]], rsuffix="_other")
        if not np.array_equal(merged.source_id.to_numpy(), merged.source_id_other.to_numpy()):
            raise ValueError("comparison rows are not aligned by source_id")
        result["paired_comparison"] = paired_macro_f1_bootstrap(
            y_true,
            probability.argmax(axis=1),
            other[["p0", "p1", "p2", "p3"]].to_numpy().argmax(axis=1),
            frame.source_id.to_numpy(),
        )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
