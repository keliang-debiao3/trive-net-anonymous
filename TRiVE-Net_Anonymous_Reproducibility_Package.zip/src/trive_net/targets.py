from __future__ import annotations

import math
from typing import Iterable

import numpy as np


QUADRANTS = ("HVHA", "LVHA", "LVLA", "HVLA")
SUNOCAPS_MAP = {
    "Happy": "HVHA",
    "Exciting": "HVHA",
    "Surprise": "HVHA",
    "Angry": "LVHA",
    "Disgust": "LVHA",
    "Sad": "LVLA",
    "Calm": "HVLA",
    "Content": "HVLA",
}


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def soft_quadrant_target(
    mu_v: float,
    sd_v: float,
    mu_a: float,
    sd_a: float,
    neutral: float = 5.0,
    epsilon: float = 1e-4,
) -> np.ndarray:
    p_v = 1.0 - _normal_cdf((neutral - mu_v) / max(sd_v, epsilon))
    p_a = 1.0 - _normal_cdf((neutral - mu_a) / max(sd_a, epsilon))
    target = np.asarray(
        [p_v * p_a, (1.0 - p_v) * p_a, (1.0 - p_v) * (1.0 - p_a), p_v * (1.0 - p_a)],
        dtype=np.float32,
    )
    return target / target.sum()


def clean_emotion(value: str) -> str:
    value = str(value).strip()
    if value.replace(" ", "_") == "Happy_simple":
        return "Happy"
    return value


def map_sunocaps_emotion(value: str) -> str:
    cleaned = clean_emotion(value)
    if cleaned not in SUNOCAPS_MAP:
        raise ValueError(f"Unsupported SunoCaps emotion label: {cleaned}")
    return SUNOCAPS_MAP[cleaned]


def encode_quadrants(labels: Iterable[str]) -> np.ndarray:
    index = {label: i for i, label in enumerate(QUADRANTS)}
    return np.asarray([index[label] for label in labels], dtype=np.int64)

