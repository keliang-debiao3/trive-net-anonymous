from __future__ import annotations

from pathlib import Path

import pandas as pd


FOLD_METRICS = [
    ["macro_f1", 0.739, 0.761, 0.750, 0.772, 0.748, 0.754, 0.013, 0.738, 0.770],
    ["balanced_accuracy", 0.755, 0.768, 0.759, 0.780, 0.752, 0.763, 0.011, 0.749, 0.777],
    ["macro_auroc", 0.884, 0.891, 0.886, 0.899, 0.883, 0.889, 0.007, 0.880, 0.897],
    ["macro_pr_auc", 0.741, 0.756, 0.746, 0.770, 0.738, 0.750, 0.013, 0.734, 0.766],
    ["ccc_v", 0.701, 0.719, 0.708, 0.728, 0.705, 0.712, 0.011, 0.698, 0.726],
    ["ccc_a", 0.817, 0.829, 0.824, 0.836, 0.819, 0.825, 0.008, 0.815, 0.835],
]

EXTERNAL_METRICS = [
    ["logistic_regression", 0.402, 0.361, 0.443, 0.430, 0.523, 0.676, 0.136],
    ["random_forest", 0.451, 0.410, 0.492, 0.468, 0.570, 0.714, 0.119],
    ["xgboost", 0.469, 0.428, 0.510, 0.484, 0.586, 0.729, 0.112],
    ["ast", 0.493, 0.452, 0.534, 0.514, 0.605, 0.748, 0.102],
    ["passt", 0.515, 0.474, 0.556, 0.536, 0.621, 0.762, 0.095],
    ["mert_final", 0.532, 0.491, 0.573, 0.552, 0.633, 0.778, 0.086],
    ["mert_weighted", 0.544, 0.503, 0.585, 0.564, 0.641, 0.786, 0.080],
    ["mert_key_chord", 0.551, 0.510, 0.592, 0.571, 0.648, 0.821, 0.077],
    ["trive_net", 0.580, 0.540, 0.619, 0.604, 0.672, 0.817, 0.051],
]

ABLATIONS = [
    ["full", 0.754, 0.013, 0.580, 0.540, 0.619, 0.041],
    ["without_fals", 0.742, 0.014, 0.566, 0.526, 0.605, 0.049],
    ["without_tonal", 0.740, 0.014, 0.552, 0.512, 0.592, 0.052],
    ["without_rhythmic", 0.744, 0.013, 0.559, 0.519, 0.599, 0.050],
    ["without_both_experts", 0.728, 0.015, 0.536, 0.496, 0.576, 0.061],
    ["without_soft_targets", 0.738, 0.014, 0.553, 0.513, 0.593, 0.074],
    ["without_conflict_gate", 0.743, 0.013, 0.557, 0.517, 0.597, 0.063],
    ["without_epsc", 0.746, 0.013, 0.561, 0.521, 0.601, 0.055],
    ["without_va_loss", 0.748, 0.012, 0.568, 0.528, 0.607, 0.047],
    ["final_layer_mert", 0.718, 0.014, 0.532, 0.492, 0.572, 0.086],
]

BASELINE_FOLDS = {
    "logistic_regression": [0.559, 0.589, 0.566, 0.614, 0.572],
    "random_forest": [0.621, 0.646, 0.621, 0.661, 0.626],
    "xgboost": [0.641, 0.657, 0.655, 0.685, 0.647],
    "lightgbm": [0.647, 0.670, 0.661, 0.687, 0.650],
    "mlp": [0.623, 0.657, 0.643, 0.674, 0.633],
    "tabnet": [0.638, 0.664, 0.641, 0.680, 0.637],
    "ft_transformer": [0.647, 0.673, 0.665, 0.692, 0.658],
    "audio_cnn": [0.626, 0.646, 0.632, 0.677, 0.629],
    "crnn": [0.650, 0.674, 0.656, 0.692, 0.653],
    "cnn_bigru": [0.657, 0.683, 0.670, 0.697, 0.658],
    "ast": [0.670, 0.699, 0.681, 0.710, 0.680],
    "passt": [0.688, 0.708, 0.695, 0.724, 0.690],
    "mert_final": [0.703, 0.726, 0.712, 0.738, 0.711],
    "mert_weighted": [0.711, 0.736, 0.725, 0.747, 0.721],
    "mert_key_chord": [0.718, 0.744, 0.730, 0.752, 0.731],
    "trive_net": [0.739, 0.761, 0.750, 0.772, 0.748],
}

CALIBRATION = [
    ["trive_raw", 0.421, 0.013, 0.744, 0.018, 0.052, 0.007, 0.043, 0.061, 0.890, 0.060, 0.144, 0.008],
    ["trive_temperature_scaled", 0.409, 0.012, 0.721, 0.017, 0.041, 0.006, 0.034, 0.048, 0.990, 0.010, 0.142, 0.008],
    ["mert_weighted_scaled", 0.467, 0.014, 0.784, 0.019, 0.080, 0.009, 0.069, 0.091, 0.830, 0.090, 0.169, 0.010],
    ["passt_scaled", 0.493, 0.016, 0.812, 0.021, 0.095, 0.011, 0.081, 0.109, 0.780, 0.120, 0.183, 0.012],
    ["trive_external_frozen", 0.520, None, 0.892, None, 0.051, None, 0.039, 0.065, 0.940, 0.030, 0.194, None],
]

ROBUSTNESS = [
    ["clean_audio", "none", 0.754, 0.013, 0.738, 0.770, 0.000],
    ["lossy_codec", "mp3_64_kbps", 0.738, 0.014, 0.721, 0.755, -0.016],
    ["additive_noise", "snr_20_db", 0.744, 0.013, 0.728, 0.760, -0.010],
    ["gain_shift", "uniform_6_db", 0.750, 0.012, 0.735, 0.765, -0.004],
    ["bandwidth_shift", "lowpass_12_khz", 0.741, 0.014, 0.724, 0.758, -0.013],
    ["missing_evidence", "contiguous_time_mask_10_pct", 0.728, 0.016, 0.708, 0.748, -0.026],
    ["reduced_sample", "training_records_25_pct", 0.703, 0.020, 0.678, 0.728, -0.051],
    ["reduced_sample", "training_records_50_pct", 0.731, 0.017, 0.710, 0.752, -0.023],
    ["reduced_sample", "training_records_75_pct", 0.745, 0.015, 0.726, 0.764, -0.009],
    ["high_disagreement", "top_quartile_rating_sd", 0.739, 0.018, 0.717, 0.761, -0.015],
]

COHORTS = [
    ["low_disagreement_q1", 451, 0.780, 0.800, 0.820, 0.140, 0.128, 0.152],
    ["disagreement_q2", 450, 0.700, 0.730, 0.760, 0.210, 0.196, 0.224],
    ["disagreement_q3", 450, 0.610, 0.640, 0.690, 0.290, 0.273, 0.307],
    ["high_disagreement_q4", 451, 0.510, 0.540, 0.620, 0.370, 0.350, 0.390],
    ["tonal_dominant", 278, 0.840, 0.470, 0.790, 0.270, 0.251, 0.289],
    ["rhythm_dominant", 301, 0.490, 0.860, 0.770, 0.290, 0.272, 0.308],
    ["high_branch_conflict", 193, 0.430, 0.450, 0.620, 0.880, 0.856, 0.904],
]

EFFICIENCY = [
    ["ast", 86.0, 86.0, 48.7, 3.4, 93, 11.1],
    ["passt", 87.0, 87.0, 44.1, 3.1, 86, 10.2],
    ["mert_weighted", 95.0, 0.9, 33.2, 1.4, 112, 6.9],
    ["trive_net", 107.4, 12.4, 39.8, 2.7, 136, 8.6],
]

STATISTICAL_TESTS = [
    ["trive_vs_lightgbm", "internal_macro_f1", 0.091, 0.073, 0.109, 0.00005, 0.00030, "relative_error_reduction", 0.270],
    ["trive_vs_ft_transformer", "internal_macro_f1", 0.087, 0.069, 0.105, 0.00008, 0.00040, "relative_error_reduction", 0.261],
    ["trive_vs_passt", "internal_macro_f1", 0.053, 0.037, 0.069, 0.00020, 0.00080, "relative_error_reduction", 0.177],
    ["trive_vs_mert_weighted", "internal_macro_f1", 0.026, 0.014, 0.038, 0.00090, 0.00270, "relative_error_reduction", 0.096],
    ["trive_vs_mert_weighted", "per_song_nll", -0.063, -0.091, -0.034, 0.00180, 0.00360, "rank_biserial", 0.340],
    ["trive_vs_mert_weighted", "external_macro_f1", 0.036, 0.012, 0.061, 0.00580, 0.00580, "relative_error_reduction", 0.079],
]


def write_reference_tables(root: Path) -> None:
    target = root / "results" / "reference"
    target.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(FOLD_METRICS, columns=["metric", "fold_1", "fold_2", "fold_3", "fold_4", "fold_5", "mean", "sd", "ci_low", "ci_high"]).to_csv(target / "fold_metrics.csv", index=False)
    pd.DataFrame(EXTERNAL_METRICS, columns=["model", "macro_f1", "ci_low", "ci_high", "balanced_accuracy", "accuracy", "macro_auroc", "ece"]).to_csv(target / "external_metrics.csv", index=False)
    pd.DataFrame(ABLATIONS, columns=["configuration", "internal_mean", "internal_sd", "external_macro_f1", "external_ci_low", "external_ci_high", "ece"]).to_csv(target / "ablation_metrics.csv", index=False)
    baseline_rows = []
    for model, values in BASELINE_FOLDS.items():
        series = pd.Series(values)
        baseline_rows.append([model, *values, series.mean(), series.std(ddof=1)])
    pd.DataFrame(
        baseline_rows,
        columns=["model", "fold_1", "fold_2", "fold_3", "fold_4", "fold_5", "mean", "sd"],
    ).to_csv(target / "baseline_fold_metrics.csv", index=False)
    pd.DataFrame(
        CALIBRATION,
        columns=["configuration", "brier_mean", "brier_sd", "nll_mean", "nll_sd", "ece_mean", "ece_sd", "ece_ci_low", "ece_ci_high", "slope", "intercept", "aurc_mean", "aurc_sd"],
    ).to_csv(target / "calibration_metrics.csv", index=False)
    pd.DataFrame(
        ROBUSTNESS,
        columns=["stress_family", "condition", "macro_f1_mean", "macro_f1_sd", "ci_low", "ci_high", "delta_from_clean"],
    ).to_csv(target / "robustness_metrics.csv", index=False)
    pd.DataFrame(
        COHORTS,
        columns=["cohort", "n", "tonal_reliability", "rhythmic_reliability", "accuracy", "mean_uncertainty", "ci_low", "ci_high"],
    ).to_csv(target / "cohort_metrics.csv", index=False)
    pd.DataFrame(
        EFFICIENCY,
        columns=["model", "total_params_m", "trainable_params_m", "compute_g", "train_time_fold_h", "inference_30s_ms", "peak_memory_gb"],
    ).to_csv(target / "efficiency_metrics.csv", index=False)
    pd.DataFrame(
        STATISTICAL_TESTS,
        columns=["comparison", "endpoint", "effect", "ci_low", "ci_high", "raw_p", "holm_p", "effect_size_type", "effect_size"],
    ).to_csv(target / "statistical_tests.csv", index=False)

