from __future__ import annotations

import numpy as np
from sklearn.metrics import accuracy_score, average_precision_score, balanced_accuracy_score, f1_score, log_loss, roc_auc_score
from sklearn.preprocessing import label_binarize


def expected_calibration_error(y_true: np.ndarray, probability: np.ndarray, bins: int = 15) -> float:
    confidence = probability.max(axis=1)
    prediction = probability.argmax(axis=1)
    order = np.argsort(confidence)
    partitions = np.array_split(order, bins)
    ece = 0.0
    for ids in partitions:
        if len(ids) == 0:
            continue
        ece += len(ids) / len(y_true) * abs((prediction[ids] == y_true[ids]).mean() - confidence[ids].mean())
    return float(ece)


def multiclass_brier(y_true: np.ndarray, probability: np.ndarray) -> float:
    one_hot = np.eye(probability.shape[1])[y_true]
    return float(np.mean(np.sum((probability - one_hot) ** 2, axis=1)))


def classification_metrics(y_true: np.ndarray, probability: np.ndarray) -> dict[str, float]:
    probability = np.asarray(probability, dtype=float)
    probability = probability / probability.sum(axis=1, keepdims=True).clip(1e-12)
    prediction = probability.argmax(axis=1)
    one_hot = label_binarize(y_true, classes=np.arange(probability.shape[1]))
    auc_values = []
    pr_values = []
    for class_index in range(probability.shape[1]):
        target = one_hot[:, class_index]
        if np.unique(target).size == 2:
            auc_values.append(roc_auc_score(target, probability[:, class_index]))
            pr_values.append(average_precision_score(target, probability[:, class_index]))
    return {
        "macro_f1": float(f1_score(y_true, prediction, average="macro")),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, prediction)),
        "accuracy": float(accuracy_score(y_true, prediction)),
        "macro_auroc": float(np.mean(auc_values)) if auc_values else float("nan"),
        "macro_pr_auc": float(np.mean(pr_values)) if pr_values else float("nan"),
        "nll": float(log_loss(y_true, probability, labels=np.arange(probability.shape[1]))),
        "brier": multiclass_brier(y_true, probability),
        "ece": expected_calibration_error(y_true, probability),
    }


def concordance_correlation(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    covariance = np.cov(y_true, y_pred, ddof=1)[0, 1]
    denominator = y_true.var(ddof=1) + y_pred.var(ddof=1) + (y_true.mean() - y_pred.mean()) ** 2
    return float(2.0 * covariance / denominator)

