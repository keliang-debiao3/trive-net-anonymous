from __future__ import annotations

import numpy as np
from sklearn.metrics import f1_score


def paired_macro_f1_bootstrap(y_true: np.ndarray, pred_a: np.ndarray, pred_b: np.ndarray, groups: np.ndarray, resamples: int = 10000, seed: int = 2026) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    unique = np.unique(groups)
    differences = np.empty(resamples, dtype=float)
    for i in range(resamples):
        sampled = rng.choice(unique, size=len(unique), replace=True)
        ids = np.concatenate([np.flatnonzero(groups == group) for group in sampled])
        differences[i] = f1_score(y_true[ids], pred_a[ids], average="macro") - f1_score(y_true[ids], pred_b[ids], average="macro")
    estimate = f1_score(y_true, pred_a, average="macro") - f1_score(y_true, pred_b, average="macro")
    low, high = np.quantile(differences, [0.025, 0.975])
    probability = 2.0 * min((differences <= 0).mean(), (differences >= 0).mean())
    return {"effect": float(estimate), "ci_low": float(low), "ci_high": float(high), "p_raw": float(probability)}


def holm_adjust(values: list[float]) -> list[float]:
    order = np.argsort(values)
    adjusted = np.empty(len(values), dtype=float)
    running = 0.0
    for rank, index in enumerate(order):
        candidate = (len(values) - rank) * values[index]
        running = max(running, candidate)
        adjusted[index] = min(running, 1.0)
    return adjusted.tolist()

