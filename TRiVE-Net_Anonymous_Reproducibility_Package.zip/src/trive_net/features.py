from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np


def _projection(input_size: int, output_size: int, key: str) -> np.ndarray:
    digest = hashlib.sha256(key.encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "little") % (2**32)
    rng = np.random.default_rng(seed)
    matrix = rng.standard_normal((input_size, output_size), dtype=np.float32)
    matrix /= np.linalg.norm(matrix, axis=0, keepdims=True).clip(1e-6)
    return matrix


def standardize_time(features: np.ndarray) -> np.ndarray:
    mean = features.mean(axis=0, keepdims=True)
    scale = features.std(axis=0, keepdims=True).clip(1e-5)
    return (features - mean) / scale


def tonal_tokens(waveform: np.ndarray, sample_rate: int, output_size: int = 384) -> np.ndarray:
    import librosa

    chroma = librosa.feature.chroma_cqt(
        y=waveform,
        sr=sample_rate,
        hop_length=480,
        n_chroma=12,
        bins_per_octave=12,
        fmin=32.70,
    )
    delta = librosa.feature.delta(chroma)
    interval = np.stack(
        [(chroma * np.roll(chroma, shift, axis=0)).mean(axis=0) for shift in range(1, 7)],
        axis=0,
    )
    tonnetz = librosa.feature.tonnetz(chroma=chroma)
    compact = np.concatenate([chroma, delta, interval, tonnetz], axis=0).T.astype(np.float32)
    compact = standardize_time(compact)
    return compact @ _projection(compact.shape[1], output_size, "tonal_relations_v1")


def rhythmic_tokens(waveform: np.ndarray, sample_rate: int, output_size: int = 384) -> np.ndarray:
    import librosa

    mel = librosa.feature.melspectrogram(
        y=waveform,
        sr=sample_rate,
        n_fft=1024,
        hop_length=240,
        n_mels=128,
        power=2.0,
    )
    log_mel = librosa.power_to_db(mel, ref=np.max)
    onset = librosa.onset.onset_strength(S=log_mel, sr=sample_rate, hop_length=240)
    tempogram = librosa.feature.tempogram(onset_envelope=onset, sr=sample_rate, hop_length=240)
    periodicity = np.stack(
        [tempogram.mean(axis=0), tempogram.max(axis=0), onset, np.gradient(onset)],
        axis=0,
    )
    compact = np.concatenate([log_mel, periodicity], axis=0).T.astype(np.float32)
    compact = standardize_time(compact)
    return compact @ _projection(compact.shape[1], output_size, "rhythmic_periodicity_v1")


def mild_delivery_shift(waveform: np.ndarray, record_id: str) -> np.ndarray:
    digest = hashlib.sha256(record_id.encode("utf-8")).digest()
    choice = digest[0] % 3
    shifted = waveform.astype(np.float32, copy=True)
    if choice == 0:
        gain_db = -6.0 + 12.0 * (digest[1] / 255.0)
        shifted *= np.float32(10.0 ** (gain_db / 20.0))
    elif choice == 1:
        rms = np.sqrt(np.mean(shifted**2) + 1e-8)
        rng = np.random.default_rng(int.from_bytes(digest[2:6], "little"))
        noise = rng.standard_normal(len(shifted)).astype(np.float32)
        shifted += noise * np.float32(rms / (10.0 ** (20.0 / 20.0)))
    else:
        start = int((digest[1] / 255.0) * max(len(shifted) - len(shifted) // 10, 1))
        shifted[start : start + len(shifted) // 10] = 0.0
    return np.clip(shifted, -1.0, 1.0)


class MERTExtractor:
    def __init__(self, model_id: str, device: str):
        import torch
        from transformers import AutoFeatureExtractor, AutoModel

        self.torch = torch
        self.device = torch.device(device)
        self.processor = AutoFeatureExtractor.from_pretrained(model_id, trust_remote_code=True)
        self.model = AutoModel.from_pretrained(model_id, trust_remote_code=True, output_hidden_states=True)
        self.model.to(self.device).eval()

    def __call__(self, waveform: np.ndarray, sample_rate: int) -> np.ndarray:
        inputs = self.processor(waveform, sampling_rate=sample_rate, return_tensors="pt")
        inputs = {key: value.to(self.device) for key, value in inputs.items()}
        with self.torch.inference_mode():
            output = self.model(**inputs, output_hidden_states=True)
        hidden = output.hidden_states[1:13]
        return np.stack([value[0].detach().cpu().numpy().astype(np.float32) for value in hidden])


def load_audio(path: str | Path, sample_rate: int = 24000) -> np.ndarray:
    import librosa

    waveform, _ = librosa.load(str(path), sr=sample_rate, mono=True)
    return waveform.astype(np.float32)


def split_windows(waveform: np.ndarray, sample_rate: int, seconds: float = 30.0) -> tuple[list[np.ndarray], np.ndarray]:
    width = int(round(sample_rate * seconds))
    windows = []
    validity = []
    for start in range(0, max(len(waveform), 1), width):
        segment = waveform[start : start + width]
        validity.append(len(segment) / width)
        if len(segment) < width:
            if len(segment) < 2:
                segment = np.pad(segment, (0, width - len(segment)), mode="constant")
            else:
                segment = np.pad(segment, (0, width - len(segment)), mode="reflect")
        windows.append(segment.astype(np.float32))
    return windows, np.asarray(validity, dtype=np.float32)
