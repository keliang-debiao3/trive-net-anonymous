"""TRiVE-Net research implementation.

Heavy neural-network dependencies are intentionally imported only by the
modules that require them.  This keeps metadata, auditing, and result-table
utilities usable on CPU-only systems before the training stack is installed.
"""

__version__ = "1.0.0"
__all__: list[str] = []

