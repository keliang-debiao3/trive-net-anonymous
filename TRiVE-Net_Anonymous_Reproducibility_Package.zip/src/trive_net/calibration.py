from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar


def apply_temperature(probability: np.ndarray, temperature: float, epsilon: float = 1e-8) -> np.ndarray:
    logits = np.log(np.clip(probability, epsilon, 1.0)) / temperature
    logits -= logits.max(axis=1, keepdims=True)
    scaled = np.exp(logits)
    return scaled / scaled.sum(axis=1, keepdims=True)


def fit_temperature(y_true: np.ndarray, probability: np.ndarray) -> float:
    def objective(value: float) -> float:
        scaled = apply_temperature(probability, value)
        return float(-np.log(np.clip(scaled[np.arange(len(y_true)), y_true], 1e-8, 1.0)).mean())

    result = minimize_scalar(objective, bounds=(0.25, 4.0), method="bounded")
    return float(result.x)

