from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class SummaryMixing(nn.Module):
    def __init__(self, width: int, expansion: int = 4, dropout: float = 0.1):
        super().__init__()
        inner = width * expansion
        self.phi = nn.Sequential(nn.LayerNorm(width), nn.Linear(width, inner), nn.GELU(), nn.Linear(inner, width))
        self.psi = nn.Sequential(
            nn.LayerNorm(width * 2),
            nn.Linear(width * 2, inner * 2),
            nn.GLU(dim=-1),
            nn.Dropout(dropout),
            nn.Linear(inner, width),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, tokens: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        if mask is None:
            summary = self.phi(tokens).mean(dim=1, keepdim=True)
        else:
            weights = mask.to(tokens.dtype).unsqueeze(-1)
            summary = (self.phi(tokens) * weights).sum(dim=1, keepdim=True) / weights.sum(dim=1, keepdim=True).clamp_min(1.0)
        mixed = self.psi(torch.cat([tokens, summary.expand_as(tokens)], dim=-1))
        return tokens + self.dropout(mixed)


class EvidenceExpert(nn.Module):
    def __init__(self, input_size: int = 384, output_size: int = 768, classes: int = 4, dropout: float = 0.1):
        super().__init__()
        self.input_projection = nn.Linear(input_size, input_size)
        self.blocks = nn.ModuleList([SummaryMixing(input_size, 4, dropout) for _ in range(2)])
        self.output_projection = nn.Linear(input_size, output_size)
        self.evidence_head = nn.Linear(output_size, classes)

    def forward(self, tokens: torch.Tensor, mask: torch.Tensor | None = None):
        hidden = self.input_projection(tokens)
        for block in self.blocks:
            hidden = block(hidden, mask)
        if mask is None:
            pooled = hidden.mean(dim=1)
        else:
            weights = mask.to(hidden.dtype).unsqueeze(-1)
            pooled = (hidden * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)
        representation = self.output_projection(pooled)
        evidence = F.softplus(self.evidence_head(representation))
        alpha = evidence + 1.0
        probability = alpha / alpha.sum(dim=-1, keepdim=True)
        uncertainty = alpha.shape[-1] / alpha.sum(dim=-1)
        return representation, probability, uncertainty


def jensen_shannon(p: torch.Tensor, q: torch.Tensor, epsilon: float = 1e-8) -> torch.Tensor:
    p = p.clamp_min(epsilon)
    q = q.clamp_min(epsilon)
    m = 0.5 * (p + q)
    return 0.5 * ((p * (p.log() - m.log())).sum(-1) + (q * (q.log() - m.log())).sum(-1))


class TRiVENet(nn.Module):
    def __init__(self, foundation_size: int = 768, expert_size: int = 384, shared_size: int = 256, classes: int = 4, gamma: float = 2.0, use_tonal: bool = True, use_rhythmic: bool = True, use_conflict_gate: bool = True):
        super().__init__()
        self.classes = classes
        self.gamma = gamma
        self.use_tonal = use_tonal
        self.use_rhythmic = use_rhythmic
        self.use_conflict_gate = use_conflict_gate
        self.foundation_head = nn.Linear(foundation_size, classes)
        self.tonal = EvidenceExpert(expert_size, foundation_size, classes)
        self.rhythmic = EvidenceExpert(expert_size, foundation_size, classes)
        self.tonal_projection = nn.Linear(foundation_size, foundation_size, bias=False)
        self.rhythmic_projection = nn.Linear(foundation_size, foundation_size, bias=False)
        self.shared = nn.Sequential(nn.LayerNorm(foundation_size), nn.Linear(foundation_size, shared_size), nn.GELU(), nn.Dropout(0.1))
        self.final_evidence = nn.Linear(shared_size, classes)
        self.va_head = nn.Linear(shared_size, 4)

    @staticmethod
    def _pool(tokens: torch.Tensor, mask: torch.Tensor | None) -> torch.Tensor:
        if mask is None:
            return tokens.mean(dim=1)
        weights = mask.to(tokens.dtype).unsqueeze(-1)
        return (tokens * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

    def forward(self, foundation_tokens: torch.Tensor, tonal_tokens: torch.Tensor, rhythmic_tokens: torch.Tensor, mask: torch.Tensor | None = None):
        foundation = self._pool(foundation_tokens, mask)
        foundation_alpha = F.softplus(self.foundation_head(foundation)) + 1.0
        foundation_probability = foundation_alpha / foundation_alpha.sum(-1, keepdim=True)

        tonal, tonal_probability, tonal_uncertainty = self.tonal(tonal_tokens, mask)
        rhythmic, rhythmic_probability, rhythmic_uncertainty = self.rhythmic(rhythmic_tokens, mask)

        tonal_conflict = jensen_shannon(tonal_probability, foundation_probability)
        rhythmic_conflict = jensen_shannon(rhythmic_probability, foundation_probability)
        tonal_penalty = torch.exp(-self.gamma * tonal_conflict) if self.use_conflict_gate else torch.ones_like(tonal_conflict)
        rhythmic_penalty = torch.exp(-self.gamma * rhythmic_conflict) if self.use_conflict_gate else torch.ones_like(rhythmic_conflict)
        tonal_reliability = (1.0 - tonal_uncertainty) * tonal_penalty
        rhythmic_reliability = (1.0 - rhythmic_uncertainty) * rhythmic_penalty
        if not self.use_tonal:
            tonal_reliability = torch.zeros_like(tonal_reliability)
        if not self.use_rhythmic:
            rhythmic_reliability = torch.zeros_like(rhythmic_reliability)
        denominator = (tonal_reliability + rhythmic_reliability).clamp_min(1e-8).unsqueeze(-1)

        expert_sum = (
            tonal_reliability.unsqueeze(-1) * self.tonal_projection(tonal)
            + rhythmic_reliability.unsqueeze(-1) * self.rhythmic_projection(rhythmic)
        )
        any_expert = ((tonal_reliability + rhythmic_reliability) > 0).to(foundation.dtype).unsqueeze(-1)
        fused = foundation + any_expert * expert_sum / denominator
        shared = self.shared(fused)
        evidence = F.softplus(self.final_evidence(shared))
        alpha = evidence + 1.0
        probability = alpha / alpha.sum(-1, keepdim=True)
        uncertainty = self.classes / alpha.sum(-1)
        raw_va = self.va_head(shared)
        mean_va = 1.0 + 8.0 * torch.sigmoid(raw_va[:, :2])
        log_variance = raw_va[:, 2:].clamp(-6.0, 3.0)
        return {
            "alpha": alpha,
            "probability": probability,
            "uncertainty": uncertainty,
            "mean_va": mean_va,
            "log_variance": log_variance,
            "tonal_reliability": tonal_reliability,
            "rhythmic_reliability": rhythmic_reliability,
            "tonal_conflict": tonal_conflict,
            "rhythmic_conflict": rhythmic_conflict,
        }

