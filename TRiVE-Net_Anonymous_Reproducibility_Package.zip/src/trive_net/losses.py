from __future__ import annotations

import torch
from torch.nn import functional as F


def evidential_loss(alpha: torch.Tensor, soft_target: torch.Tensor, kl_weight: float) -> torch.Tensor:
    expected_ce = (soft_target * (torch.digamma(alpha.sum(-1, keepdim=True)) - torch.digamma(alpha))).sum(-1).mean()
    adjusted = soft_target + (1.0 - soft_target) * alpha
    prior = torch.ones_like(adjusted)
    sum_a = adjusted.sum(-1)
    sum_p = prior.sum(-1)
    log_normalizer = torch.lgamma(sum_a) - torch.lgamma(adjusted).sum(-1) - torch.lgamma(sum_p) + torch.lgamma(prior).sum(-1)
    digamma_term = ((adjusted - prior) * (torch.digamma(adjusted) - torch.digamma(sum_a).unsqueeze(-1))).sum(-1)
    return expected_ce + kl_weight * (log_normalizer + digamma_term).mean()


def va_loss(mean_va: torch.Tensor, log_variance: torch.Tensor, target_mean: torch.Tensor, observed_sd: torch.Tensor, epsilon: float = 1e-8) -> torch.Tensor:
    variance = log_variance.exp() + observed_sd.square() + epsilon
    return 0.5 * (((target_mean - mean_va).square() / variance) + variance.log()).sum(-1).mean()


def consistency_loss(clean: dict, shifted: dict, rho: float = 0.25) -> torch.Tensor:
    p = clean["probability"].clamp_min(1e-8)
    q = shifted["probability"].clamp_min(1e-8)
    m = 0.5 * (p + q)
    jsd = 0.5 * (F.kl_div(m.log(), p, reduction="batchmean") + F.kl_div(m.log(), q, reduction="batchmean"))
    uncertainty = (clean["uncertainty"] - shifted["uncertainty"]).abs().mean()
    return jsd + rho * uncertainty


def total_loss(clean: dict, soft_target: torch.Tensor, target_mean: torch.Tensor, observed_sd: torch.Tensor, kl_weight: float, shifted: dict | None = None, lambda_va: float = 0.35, lambda_consistency: float = 0.20, rho: float = 0.25) -> dict:
    edl = evidential_loss(clean["alpha"], soft_target, kl_weight)
    va = va_loss(clean["mean_va"], clean["log_variance"], target_mean, observed_sd)
    cons = clean["alpha"].new_zeros(()) if shifted is None else consistency_loss(clean, shifted, rho)
    total = edl + lambda_va * va + lambda_consistency * cons
    return {"total": total, "edl": edl, "va": va, "consistency": cons}

