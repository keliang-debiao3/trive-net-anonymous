# Anonymous review status

This package contains no author names, affiliations, institutional paths, personal addresses, repository history, acknowledgements, funding identifiers, or persistent identifiers linked to the authors.

The software citation identifies the contributors only as Anonymous Authors. Public release metadata can be added after the review process without changing the research implementation.
