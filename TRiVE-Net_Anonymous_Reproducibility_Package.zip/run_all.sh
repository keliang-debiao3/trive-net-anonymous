#!/usr/bin/env bash
set -euo pipefail

python scripts/build_reference_artifacts.py
python scripts/verify_repository.py
python scripts/run_light_checks.py

if command -v pytest >/dev/null 2>&1; then
  pytest -q
else
  echo "pytest_status=SKIPPED dependency_not_installed=true"
fi

echo "repository_checks=PASS"

