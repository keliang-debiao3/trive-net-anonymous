# TRiVE-Net Anonymous Reproducibility Package

This repository contains the implementation and audit workflow for TRiVE-Net, a tonal-rhythmic evidential network for cross-corpus music emotion prediction.

## Repository scope

- DEAM development and grouped five-fold validation
- SunoCaps frozen external validation
- Fold-Adaptive Foundation Layer Selection
- Tonal and rhythmic SummaryMixing experts
- Conflict-sensitive evidential fusion
- Human-variance-aware categorical and dimensional objectives
- Fold-specific temperature scaling
- Baseline, ablation, calibration, robustness, statistical, and efficiency workflows
- Manuscript-matched result matrices and reference traces

The files under `results/reference` and `logs/reference` are deterministic artifacts generated from the numerical matrices reported in the manuscript. They verify parsing, aggregation, statistical formatting, and repository wiring. They are not presented as raw accelerator telemetry. Running the training workflow writes new artifacts to `results/runs` and `logs/runs`.

## Data

The audio is not redistributed. Obtain the public corpora from:

- DEAM: https://www.kaggle.com/datasets/imsparsh/deam-mediaeval-dataset-emotional-analysis-in-music
- SunoCaps: https://www.kaggle.com/datasets/miguelcivit/sunocaps

Place the downloaded files under paths of your choice and build the manifests described in `data/README.md`.

## Environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Python 3.11 and CUDA-capable PyTorch are recommended. CPU execution is supported for repository checks and result-table reconstruction.

## Fast repository verification

```bash
python scripts/build_reference_artifacts.py
python scripts/verify_repository.py
python scripts/run_light_checks.py
pytest -q
```

## Feature caching

```bash
python scripts/build_features.py --dataset deam --manifest /path/to/deam_manifest.csv --output-dir /path/to/deam_cache
python scripts/build_features.py --dataset sunocaps --manifest /path/to/sunocaps_manifest.csv --output-dir /path/to/sunocaps_cache
```

Feature records contain the 12 frozen MERT candidate layers, tonal-relation tokens, rhythmic-periodicity tokens, label information where applicable, immutable group identifiers, and a delivery-shifted copy used only by the training consistency objective. Feature extraction is label-independent.

## Main study workflow

```bash
bash run_study.sh \
  /path/to/deam_manifest.csv \
  /path/to/sunocaps_manifest.csv \
  /path/to/deam_cache \
  /path/to/sunocaps_cache \
  study_run
```

This command audits the manifests, creates song-grouped folds before model fitting, trains three seeds per fold, generates one out-of-fold prediction per DEAM recording, averages the frozen fold/seed predictions for SunoCaps, and reports external metrics without external refitting.

Layer selection is independently reproducible with `scripts/select_layers.py` from an inner-fold candidate-metric table containing `fold`, `layer`, `probe_score`, `pitch_equivariance`, and `redundancy`. Component removal is performed with `scripts/run_ablations.py`; each configuration maps directly to one row of the manuscript ablation table.

## Expected manifest columns

DEAM:

`path,song_id,mu_v,sd_v,mu_a,sd_a`

SunoCaps:

`path,source_id,emotion`

The primary SunoCaps emotion field is standardized before mapping. `Extra_emotion`, prompt text, and comments are excluded from the prediction target and model input.

## Leakage controls

- Song and source groups are assigned before window extraction.
- Scaling, search, layer selection, calibration, and threshold selection are fitted within the outer-training partition.
- SunoCaps labels are never used for model fitting or temperature selection.
- External bootstrap resampling retains the four generated variants within each MusicCaps source group.

## Main configuration

`configs/trive_deam.yaml` records the selected fold layers, seeds, model dimensions, loss coefficients, optimization schedule, label mapping, and statistical settings used in the manuscript.

## Outputs

- `results/runs/fold_metrics.csv`
- `results/runs/external_metrics.csv`
- `results/runs/ablation_metrics.csv`
- `results/runs/calibration_metrics.csv`
- `results/runs/robustness_metrics.csv`
- `results/runs/statistical_tests.csv`
- `logs/runs/*.log`

All tabular outputs use recording-level or source-group-level units as specified in the manuscript.

