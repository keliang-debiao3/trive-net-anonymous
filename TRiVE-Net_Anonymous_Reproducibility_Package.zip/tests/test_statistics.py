import numpy as np

from trive_net.statistics import holm_adjust


def test_holm_family():
    raw = [0.00005, 0.00008, 0.00020, 0.00090, 0.00180, 0.00580]
    adjusted = holm_adjust(raw)
    expected = [0.00030, 0.00040, 0.00080, 0.00270, 0.00360, 0.00580]
    assert np.allclose(adjusted, expected)

