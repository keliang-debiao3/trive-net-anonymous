import numpy as np
import torch

from trive_net.calibration import apply_temperature
from trive_net.model import TRiVENet
from trive_net.targets import map_sunocaps_emotion, soft_quadrant_target


def test_target_normalization():
    target = soft_quadrant_target(6.5, 1.0, 4.0, 0.8)
    assert target.shape == (4,)
    assert np.isclose(target.sum(), 1.0)
    assert np.all(target >= 0.0)


def test_external_mapping():
    assert map_sunocaps_emotion(" Happy ") == "HVHA"
    assert map_sunocaps_emotion("Happy simple") == "HVHA"
    assert map_sunocaps_emotion("Sad") == "LVLA"


def test_model_outputs():
    model = TRiVENet()
    output = model(torch.randn(2, 12, 768), torch.randn(2, 12, 384), torch.randn(2, 12, 384))
    assert output["probability"].shape == (2, 4)
    assert torch.allclose(output["probability"].sum(-1), torch.ones(2), atol=1e-5)
    assert output["mean_va"].min() >= 1.0
    assert output["mean_va"].max() <= 9.0


def test_temperature_scaling():
    probability = np.asarray([[0.7, 0.1, 0.1, 0.1], [0.1, 0.6, 0.2, 0.1]])
    scaled = apply_temperature(probability, 1.2)
    assert np.allclose(scaled.sum(axis=1), 1.0)

