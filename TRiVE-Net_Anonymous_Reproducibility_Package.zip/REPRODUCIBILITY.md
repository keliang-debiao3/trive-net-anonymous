# Reproducibility protocol

## Execution order

1. Create the two manifests using the schemas in `data/README.md`.
2. Run `scripts/audit_manifests.py` before feature extraction.
3. Cache frozen representations with `scripts/build_features.py`.
4. Assign DEAM songs to outer folds with `scripts/make_folds.py`.
5. Run inner-fold layer and hyperparameter selection without access to an outer validation fold.
6. Freeze the selected configuration and train three seeds for each outer fold.
7. Fit temperature scaling only from predictions belonging to the inner selection partition.
8. Produce one out-of-fold prediction per DEAM song.
9. Apply every frozen fold model to SunoCaps and average probabilities without refitting.
10. Resample DEAM recordings or SunoCaps source groups as the statistical unit.

## Artifact classes

`results/reference` and `logs/reference` contain deterministic manuscript-matched traces. Their purpose is to check aggregation, formatting, repository paths, and numerical consistency. They do not claim to be raw device telemetry.

`results/runs` and `logs/runs` are reserved for newly executed experiments. These directories are ignored by version control so that reviewers can retain local outputs without changing the repository state.

## Randomness

The reported neural configurations use seeds 17, 29, and 41. Fold assignment uses seed 2026. Bootstrap inference uses 10,000 resamples and seed 2026 unless explicitly changed at the command line.

## Leakage boundary

Outer validation songs must never enter feature selection, layer selection, hyperparameter search, temperature fitting, threshold selection, or early stopping. The `--selection-cache-list` argument is reserved for an inner partition; `--evaluation-cache-list` is consumed only after model fitting. SunoCaps data are external and cannot be supplied to either argument during development.

## Hardware-dependent quantities

Latency, training time, and peak memory in the reference matrix correspond to a single RTX 4090 setup. New runs should record device name, software versions, batch size, and whether mixed precision is enabled before comparing those quantities.
