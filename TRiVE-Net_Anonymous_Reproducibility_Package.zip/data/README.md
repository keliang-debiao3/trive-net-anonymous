# Data layout

Audio files are not included in this repository.

Create two CSV manifests.

## DEAM manifest

Required columns:

- `path`: absolute or repository-relative audio path
- `song_id`: immutable recording identifier
- `mu_v`: static mean valence on the 1–9 scale
- `sd_v`: static valence standard deviation
- `mu_a`: static mean arousal on the 1–9 scale
- `sd_a`: static arousal standard deviation

The expected analytical sample contains 1,802 recordings. Group assignment must use `song_id` before any audio window is created.

## SunoCaps manifest

Required columns:

- `path`: audio path
- `source_id`: MusicCaps source identifier shared by four generated variants
- `emotion`: primary Emotion field

The expected external sample contains 256 tracks from 64 source identifiers. Leading and trailing whitespace is removed, and `Happy simple` is standardized as `Happy`. Prompt text, comments, and supplementary emotion fields are not used as model input or target.

## Feature cache

`scripts/build_features.py` writes one compressed record per song. The cache stores deterministic MERT layer sequences, tonal tensors, rhythmic tensors, window-validity weights, and immutable identifiers. Cache fitting does not use labels. Fold-specific scaling or model selection is performed after grouped splitting.

